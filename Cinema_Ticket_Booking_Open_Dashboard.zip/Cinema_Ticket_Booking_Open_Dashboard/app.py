from flask import Flask, render_template, request, redirect, url_for, flash
from pathlib import Path
from datetime import datetime
import json
import threading

app = Flask(__name__)
app.secret_key = "cinema-demo-local-key"
DATA_FILE = Path(__file__).parent / "data.json"
DATA_LOCK = threading.Lock()

INITIAL_DATA = {
    "movies": [
        {"id": 1, "name": "Jawan", "genre": "Action", "price": 200},
        {"id": 2, "name": "3 Idiots", "genre": "Comedy", "price": 150},
        {"id": 3, "name": "Interstellar", "genre": "Sci-Fi", "price": 250}
    ],
    "shows": [
        {"id": 1, "movie_id": 1, "time": "2026-10-29 18:00", "total_seats": 50, "available_seats": 50},
        {"id": 2, "movie_id": 2, "time": "2026-10-29 20:00", "total_seats": 50, "available_seats": 50},
        {"id": 3, "movie_id": 3, "time": "2026-10-30 17:00", "total_seats": 50, "available_seats": 50}
    ],
    "bookings": [],
    "next_movie_id": 4,
    "next_show_id": 4,
    "next_booking_id": 1
}

def load_data():
    with DATA_LOCK:
        if not DATA_FILE.exists():
            save_data_unlocked(INITIAL_DATA)
        try:
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            save_data_unlocked(INITIAL_DATA)
            return json.loads(json.dumps(INITIAL_DATA))

def save_data_unlocked(data):
    DATA_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

def save_data(data):
    with DATA_LOCK:
        save_data_unlocked(data)

def movie_for(data, movie_id):
    return next((m for m in data["movies"] if m["id"] == movie_id), None)

def dashboard_data():
    data = load_data()
    movies_by_id = {m["id"]: m for m in data["movies"]}
    shows = []
    for s in data["shows"]:
        movie = movies_by_id.get(s["movie_id"], {})
        shows.append({**s, "movie_name": movie.get("name", "Unknown"),
                      "genre": movie.get("genre", ""),
                      "price": movie.get("price", 0)})
    bookings = []
    for b in reversed(data["bookings"]):
        s = next((x for x in data["shows"] if x["id"] == b["show_id"]), {})
        m = movies_by_id.get(s.get("movie_id"), {})
        bookings.append({**b, "movie_name": m.get("name", "Unknown"),
                         "show_time": s.get("time", "Unknown")})
    total_tickets = sum(b["tickets"] for b in data["bookings"])
    collection = sum(b["total_amount"] for b in data["bookings"])
    return data, shows, bookings, total_tickets, collection

@app.route("/")
def index():
    data, shows, bookings, total_tickets, collection = dashboard_data()
    return render_template("index.html", movies=data["movies"], shows=shows,
                           bookings=bookings, total_tickets=total_tickets,
                           collection=collection)

@app.post("/book")
def book():
    customer = request.form.get("customer_name", "").strip()
    try:
        show_id = int(request.form.get("show_id", ""))
        tickets = int(request.form.get("tickets", ""))
    except ValueError:
        flash("Please choose a show and enter a valid ticket quantity.", "error")
        return redirect(url_for("index"))

    data = load_data()
    show = next((s for s in data["shows"] if s["id"] == show_id), None)
    if not customer:
        flash("Customer name is required.", "error")
    elif tickets <= 0:
        flash("Ticket quantity must be at least 1.", "error")
    elif show is None:
        flash("Selected show was not found.", "error")
    elif show["available_seats"] < tickets:
        flash(f"Only {show['available_seats']} seat(s) are available.", "error")
    else:
        movie = movie_for(data, show["movie_id"])
        amount = movie["price"] * tickets
        booking = {
            "id": data["next_booking_id"], "customer_name": customer,
            "show_id": show_id, "tickets": tickets, "total_amount": amount,
            "booking_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        show["available_seats"] -= tickets
        data["bookings"].append(booking)
        data["next_booking_id"] += 1
        save_data(data)
        flash(f"Booking successful! Booking ID #{booking['id']} · Total ₹{amount:,}", "success")
    return redirect(url_for("index"))

@app.post("/movie")
def add_movie():
    name = request.form.get("movie_name", "").strip()
    genre = request.form.get("genre", "").strip() or "Other"
    try:
        price = float(request.form.get("price", ""))
    except ValueError:
        price = 0
    if not name or price <= 0:
        flash("Enter a movie name and a ticket price greater than zero.", "error")
        return redirect(url_for("index"))
    data = load_data()
    movie_id = data["next_movie_id"]
    data["movies"].append({"id": movie_id, "name": name, "genre": genre, "price": price})
    data["next_movie_id"] += 1
    # Automatically create a show for tomorrow at 18:00
    from datetime import timedelta
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    show_id = data["next_show_id"]
    data["shows"].append({"id": show_id, "movie_id": movie_id,
                          "time": f"{tomorrow} 18:00", "total_seats": 50,
                          "available_seats": 50})
    data["next_show_id"] += 1
    save_data(data)
    flash(f"Movie added and a show created (Show ID #{show_id}).", "success")
    return redirect(url_for("index"))

@app.post("/reset")
def reset():
    save_data(json.loads(json.dumps(INITIAL_DATA)))
    flash("Demo data reset. All demo bookings were cleared.", "success")
    return redirect(url_for("index"))

if __name__ == "__main__":
    print("\nCinema Ticket Booking Dashboard is starting...")
    print("Open this address in your browser: http://127.0.0.1:5000")
    print("Keep this terminal open while using the dashboard. Press Ctrl+C to stop.\n")
    app.run(debug=False, host="127.0.0.1", port=5000)
