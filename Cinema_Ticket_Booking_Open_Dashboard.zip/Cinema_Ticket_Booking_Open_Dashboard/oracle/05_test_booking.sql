BEGIN
    book_ticket('Rahul Sharma', 1, 2);
END;
/

SELECT * FROM bookings ORDER BY booking_id DESC;
SELECT show_id, available_seats FROM movie_shows ORDER BY show_id;
