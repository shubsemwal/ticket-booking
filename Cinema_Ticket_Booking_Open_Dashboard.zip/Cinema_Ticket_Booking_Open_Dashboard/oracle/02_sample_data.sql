INSERT INTO movies (movie_name, genre, ticket_price) VALUES ('Jawan', 'Action', 200);
INSERT INTO movies (movie_name, genre, ticket_price) VALUES ('3 Idiots', 'Comedy', 150);
INSERT INTO movies (movie_name, genre, ticket_price) VALUES ('Interstellar', 'Sci-Fi', 250);
INSERT INTO movie_shows (movie_id, show_time, total_seats, available_seats) VALUES (1, TIMESTAMP '2026-10-29 18:00:00', 50, 50);
INSERT INTO movie_shows (movie_id, show_time, total_seats, available_seats) VALUES (2, TIMESTAMP '2026-10-29 20:00:00', 50, 50);
INSERT INTO movie_shows (movie_id, show_time, total_seats, available_seats) VALUES (3, TIMESTAMP '2026-10-30 17:00:00', 50, 50);
COMMIT;
