CREATE OR REPLACE PROCEDURE book_ticket (
    p_customer_name IN VARCHAR2,
    p_show_id IN NUMBER,
    p_tickets IN NUMBER
)
AS
    v_available NUMBER;
    v_price NUMBER(8,2);
    v_amount NUMBER(10,2);
    v_booking_id NUMBER;
BEGIN
    IF p_customer_name IS NULL OR TRIM(p_customer_name) IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'Customer name is required.');
    END IF;
    IF p_tickets IS NULL OR p_tickets <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Enter a valid ticket quantity.');
    END IF;

    SELECT s.available_seats, m.ticket_price
      INTO v_available, v_price
      FROM movie_shows s JOIN movies m ON m.movie_id = s.movie_id
     WHERE s.show_id = p_show_id
       FOR UPDATE OF s.available_seats;

    IF v_available < p_tickets THEN
        RAISE_APPLICATION_ERROR(-20003, 'Not enough seats available.');
    END IF;

    v_amount := v_price * p_tickets;
    UPDATE movie_shows SET available_seats = available_seats - p_tickets
     WHERE show_id = p_show_id;

    INSERT INTO bookings (customer_name, show_id, tickets, total_amount)
    VALUES (TRIM(p_customer_name), p_show_id, p_tickets, v_amount)
    RETURNING booking_id INTO v_booking_id;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Booking ID: ' || v_booking_id);
    DBMS_OUTPUT.PUT_LINE('Total amount: Rs. ' || v_amount);
    DBMS_OUTPUT.PUT_LINE('Booking successful!');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20004, 'Show not found.');
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END;
/
