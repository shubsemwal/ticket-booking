SELECT COUNT(*) AS total_movies FROM movies;
SELECT COUNT(*) AS total_shows FROM movie_shows;
SELECT NVL(SUM(tickets), 0) AS tickets_booked FROM bookings;
SELECT NVL(SUM(total_amount), 0) AS total_collection FROM bookings;

SELECT s.show_id, m.movie_name, m.genre, s.show_time,
       m.ticket_price, s.total_seats, s.available_seats
FROM movie_shows s JOIN movies m ON m.movie_id = s.movie_id
ORDER BY s.show_time;

SELECT b.booking_id, b.customer_name, m.movie_name, s.show_time,
       b.tickets, b.total_amount, b.booking_date
FROM bookings b
JOIN movie_shows s ON s.show_id = b.show_id
JOIN movies m ON m.movie_id = s.movie_id
ORDER BY b.booking_date DESC;
