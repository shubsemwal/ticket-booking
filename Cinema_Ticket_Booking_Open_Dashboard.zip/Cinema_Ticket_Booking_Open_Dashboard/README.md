# Cinema Ticket Booking — Open Dashboard (VS Code)

This project opens a dashboard window in your browser and supports:
- View movies and showtimes
- Book tickets
- Check remaining seats
- View booking history and total collection
- Add a movie/show (demo mode)

## Important
This is a **local demo dashboard** that runs in VS Code with Python. It stores data in a local JSON file and does **not** connect to Oracle PL/SQL yet. This makes the dashboard easy to run immediately. If your teacher requires Oracle PL/SQL execution, use the provided `oracle/` scripts too, or tell me and I can connect the UI to Oracle using a Python Oracle driver.

## Requirements
- Windows 10/11
- Python 3.10+ installed
- VS Code

## Run on Windows
1. Extract this ZIP folder.
2. Open the extracted `Cinema_Ticket_Booking_Open_Dashboard` folder in VS Code.
3. In VS Code choose **Terminal → New Terminal**.
4. Run:
   ```powershell
   python --version
   ```
   If a Python version appears, continue.
5. Install dependency:
   ```powershell
   python -m pip install flask
   ```
6. Start dashboard:
   ```powershell
   python app.py
   ```
7. Open the URL shown in terminal, usually `http://127.0.0.1:5000`.

Keep the terminal running while using the dashboard. Press `Ctrl+C` to stop it.

## Oracle PL/SQL scripts
The `oracle/` folder includes table creation, sample data, and a booking procedure. Run these in Oracle SQL Developer / APEX SQL Workshop if your course requires actual PL/SQL.
